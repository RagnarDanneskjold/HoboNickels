HoboNickels Crypto Tokens

2% proof of stake every 10 days.

Based on NVC/BitGems/Bottlecaps
Proof of Work/Proof of Stake Hybrid
Scrypt
Linear Difficulty Retarget
5 Confirms
5 Tokens Per Block
Maximum of 120000000 Tokens
Default P2P Port: 7372
Default RPC Port: 7373
